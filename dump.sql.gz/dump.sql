-- MySQL dump 10.13  Distrib 5.7.35-38, for Linux (x86_64)
--
-- Host: localhost    Database: symfony_im_collaborate
-- ------------------------------------------------------
-- Server version	5.7.35-38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_64C19C1727ACA70` (`parent_id`),
  CONSTRAINT `FK_64C19C1727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,NULL,'Кроссовки-1','2022-03-01 18:04:45','2022-03-01 18:04:45',1),(2,NULL,'Ботинки-1','2022-03-01 18:04:59','2022-03-01 18:04:59',1),(3,1,'Кеды-1','2022-03-01 18:05:13','2022-03-01 18:05:13',1),(4,1,'Кеды-2','2022-03-01 21:44:05','2022-03-01 21:44:05',1),(5,2,'СуперБотинки-1','2022-03-01 21:45:42','2022-03-01 21:46:37',1),(8,NULL,'Категория-3','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(9,9,'ПодКатегория-3-1','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(10,NULL,'Категория-4','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(11,11,'ПодКатегория-4-1','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(12,NULL,'Категория-5','2022-03-05 00:00:00','2022-03-05 00:00:00',1),(13,13,'ПодКатегория-5-1','2022-03-05 00:00:00','2022-03-05 00:00:00',1),(46,NULL,'Категория-6','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(47,46,'ПодКатегория-6-1','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(48,46,'ПодКатегория-6-2','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(49,48,'ПодКатегория-6-2-1','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(50,48,'ПодКатегория-6-2-2','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(51,NULL,'Категория-7','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(52,51,'ПодКатегория-7-1','2022-03-05 14:05:26','2022-03-05 14:05:26',1),(53,51,'ПодКатегория-7-2','2022-03-05 14:05:26','2022-03-05 14:05:26',1);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526C4584665A` (`product_id`),
  CONSTRAINT `FK_9474526C4584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (24,22,'TestUser Abddg','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(25,22,'TestUser Gghff','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',1),(26,22,'TestUser Bffsf','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',3),(27,22,'TestUser Ysdsd','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(28,23,'TestUser Abddg','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',3),(29,23,'TestUser Gghff','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',2),(30,23,'TestUser Bffsf','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',4),(31,23,'TestUser Ysdsd','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(32,24,'TestUser Abddg','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',1),(33,24,'TestUser Gghff','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',4),(34,24,'TestUser Bffsf','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(35,24,'TestUser Ysdsd','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(36,25,'TestUser Abddg','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',4),(37,25,'TestUser Gghff','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',2),(38,25,'TestUser Bffsf','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(39,25,'TestUser Ysdsd','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',1),(40,27,'TestUser Abddg','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(41,27,'TestUser Gghff','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',5),(42,27,'TestUser Bffsf','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',3),(43,27,'TestUser Ysdsd','2022-03-05 14:05:26','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20220228215316','2022-03-01 13:28:07',1449);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_product`
--

DROP TABLE IF EXISTS `order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `order_ref_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2530ADE64584665A` (`product_id`),
  KEY `IDX_2530ADE6E238517C` (`order_ref_id`),
  CONSTRAINT `FK_2530ADE64584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK_2530ADE6E238517C` FOREIGN KEY (`order_ref_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_product`
--

LOCK TABLES `order_product` WRITE;
/*!40000 ALTER TABLE `order_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `price` double NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,3,'СуперКеды1','ыфаыавпвпвп','2022-03-01 21:47:51','2022-03-01 21:47:51',100,1),(2,3,'СуперКеды-222','ыарвпвпоп','2022-03-01 21:48:36','2022-03-01 21:48:36',120,1),(22,47,'Продукт6-1_1','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo,neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',150,1),(23,47,'Продукт6-1_2','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo, neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',251,1),(24,49,'Продукт6-2-1_1','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo, neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',200,1),(25,49,'Продукт6-2-1_2','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo, neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',186,1),(26,50,'Продукт6-2-2_1','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo, neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',185,1),(27,50,'Продукт6-2-2_2','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut commodo, neque consectetur congue congue, neque arcu suscipit metus, quis imperdiet.','2022-03-05 14:05:26','2022-03-05 14:05:26',122,1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-07 15:53:12
